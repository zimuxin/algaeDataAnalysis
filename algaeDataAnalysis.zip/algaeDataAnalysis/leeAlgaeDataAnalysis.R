#海藻数据分析
#作者：李艳东 
#学号：2120151006

#读取数据
#algaeData<-read.table("C:/Users/lenovo/Desktop/DataMining/Analysis.txt",,col.names=c('season', 'size', 'speed', 'mxPH', 'mnO2', 'Cl', 'NO3', 'NH4', 'oPO4', 'PO4', 'Chla', 'a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7'),na.strings=c('XXXXXXX'))
algaeData<-read.table(file.choose(),,col.names=c('season', 'size', 'speed', 'mxPH', 'mnO2', 'Cl', 'NO3', 'NH4', 'oPO4', 'PO4', 'Chla', 'a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7'),na.strings=c('XXXXXXX'))
head(algaeData)

#获取数据摘要
summary(algaeData)

#绘制mxPH直方图
hist(algaeData$mxPH,probability = T)

#用qq图检验其分布是否为正态分布
library(car)
par(mfrow=c(1,2))
hist(algae$mxPH,prob=T,xlab = "",ylim = 0:1,main = "Histogram of maximum pH value")
lines(density(algae$mxPH,na.rm=T))
rug(jitter(algae$mxPH))
qq.plot(algae$mxPH,main="Normal QQ plot of maximum pH")

#检测OPO4
boxplot(algaeData$oPO4,ylab="Orthophosphate")
rug(jitter(algaeData$oPO4),side = 2)
abline(h=mean(algaeData$oPO4,na.rm = T),lty=2)

#识别特大值相应的水样：
plot(algaeData$NH4,xlab = "")
abline(h=mean(algaeData$NH4,na.rm = T),lty=1)
abline(h=mean(algaeData$NH4,na.rm = T)+sd(algaeData$NH4,na.rm = T),lty=2)
abline(h=median(algaeData$NH4,na.rm = T),lty=3)
identify(algaeData$NH4)

#研究变量size如何影响变量a1值的分布
bwplot(size~a1,data=algaeData,ylab = "River Size",xlab = "Algal A1")

#绘制a1变量的条件分位箱图
library(Hmisc)
bwplot(size~a1,data=algaeData,panel = panel.bpplot,probs=seq(.01,.49,by=.01),datadensity=T,ylab="River Size",xlab = "Algal A1")

#两因子条件绘图的例子。考虑变量a3在给定变量season和变量mnO2下的条件绘图，变量mnO2是一个连续变量
m1<-equal.count(na.omit(algaeData$mnO2),number=4,overlap=1/5)
stripplot(season~a3|m1,data = algaeData[!is.na(algaeData$mnO2),])

#将缺失部分剔除
algaeData[!complete.cases(algaeData),]
nrow(algaeData[!complete.cases(algaeData),])
algaeData <- na.omit(algaeData)
algaeData <- algaeData[-c(62,199),]
apply(algaeData,1,function(x) sum(is.na(x)))
data(algaeData)
manyNAs(algaeData,0.2)
algaeData <- algaeData[-manyNAs(algaeData),]
write.table(algaeData,file = 'AnalysisAfter1.txt',quote=FALSE,sep='\t',row.names =FALSE, col.names = FALSE)

#用高频率值来填补缺失值
algaeData[48,'mxPH'] <- mean(algaeData$mxPH,na.rm=T)
algaeData[is.na(algaeData$Chla),'Chla'] <- median(algaeData$Chla,na.rm=T)
write.table(algaeData,file = 'AnalysisAfter2.txt',quote=FALSE,sep='\t',row.names =FALSE, col.names = FALSE)

#通过属性的相关关系来填补缺失值
options(digits = 1)
cor(algaeData[,4:18],use="complete.obs")
symnum(cor(algaeData[,4:18],use="complete.obs"))
attr(,"legend")
data(algaeData)
algaeData<-algaeData[-manyNAs(algaeData),]
lm(PO4~oPO4,data = algaeData)
algaeData[28,'PO4'] <- 42.897 + 1.293 * algaeData[28,'oPO4']
algaeData[28,"PO4"]
histogram(~mxPH|season,data=algaeData)
histogram(~mxPH|season,data=algaeData)
stripplot(size~mxPH|speed,data=algaeData,jitter=T)
write.table(algaeData,file = 'AnalysisAfter3.txt',quote=FALSE,sep='\t',row.names =FALSE, col.names = FALSE)

#通过数据对象之间的相似性来填补缺失值
algaeData<-algaeData[-manyNAs(algaeData),]
algaeData<-knnImputation(algaeData,k=10)
algaeData
algaeData<-knnImputation(algaeData,k=10,meth = "median")
write.table(algaeData,file = 'AnalysisAfter4.txt',quote=FALSE,sep='\t',row.names =FALSE, col.names = FALSE)

